

window.onload = async function() {
    
    document.body.addEventListener('keypress', function (eventObj) {
        if (eventObj.key == '1'){
            document.getElementById("newPlayerForm").style.display = "block";
        }
        else if(eventObj.key == '2'){
            document.getElementById("loginForm").style.display = "block";
        }
        else if(eventObj.key == '3'){
            window.location.href='/about';
        }
        else if(eventObj.key == '4'){
            window.location.href='/options';
        }
        else if(eventObj.key == '5'){
            window.location.href='/credits';
        }
    });
    document.getElementById("newGame").addEventListener('click',function(){
        document.getElementById("newPlayerForm").style.display = "block";
    });
    
    document.getElementById("newPlayerForm").addEventListener('submit',async evt =>{
        evt.preventDefault();
        const playerName = evt.target.querySelector("input").value;
        const res = await fetch("http://localhost:3000/api/players",{
            method : 'POST',
            body: JSON.stringify({
                name : playerName
            }),
            headers: {"Content-type" : "application/json; charset=UTF-8"}
        });
        if(res.ok){
            localStorage.setItem("playerName", playerName);
        }
        window.location.href = '/game';
    });  

    
    document.getElementById("loadGame").addEventListener('click',function(){
       document.getElementById("loginForm").style.display = "block";
    });
    
    document.getElementById("loginForm").addEventListener('submit',async evt =>{
        evt.preventDefault();
        const playerName = evt.target.querySelector("input").value;
        const res = await fetch("http://localhost:3000/api/players/" + playerName);
        if(res.ok){
            localStorage.setItem("playerName",playerName);
            window.location.href = '/game';
        }
        else
            alert("Player not found");
    });
    
    document.getElementById("how").addEventListener('click',function(){
        window.location.href='/about';
    });
    
    document.getElementById("options").addEventListener('click',function(){
        window.location.href='/options';
    });
    
    document.getElementById("credits").addEventListener('click',function(){
        window.location.href='/credits';
    });
    

    
    
    
    /*var ocan = document.getElementById("myaudio");
    var isPlaying = false;
    
    function togglePlay(){
        if(isPlaying){
            ocan.pause();
        }
            else{
                ocan.play();
            }
    };
    
    ocan.onplaying = function() {
        isPlaying = true;
    };
    
    ocan.onpause = function() {
        isPlaying = false;
    };*/
    
    
}