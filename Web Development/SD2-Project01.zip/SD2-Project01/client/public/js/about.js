window.onload = function() {
    document.body.addEventListener('keydown', function(eventObj){

        eventObj.preventDefault();
        //code 27 for escape
        if(eventObj.key == 'Escape'){
            window.location.href='/menu';
        }
    });
}