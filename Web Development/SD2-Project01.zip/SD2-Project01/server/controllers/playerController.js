var PlayerModel = require("../models/player.js");
var RoomModel = require("../models/room.js");
var ItemModel = require("../models/item.js");

exports.readAllPlayers = (req, res) => {
  res.send(PlayerModel.players);
}

exports.createPlayer = (req, res) => {
  if (req.body) {
    if (req.body.name) {
      let p = new PlayerModel.Player(req.body.name);
      PlayerModel.players[p.name] = p;
      res.status(201).send(p);
    } else {
      res.status(400).send("New player data must contain a name.");
    }
  } else {
    res.status(400).send("Missing player data.");
  }
};

exports.readPlayer = (req, res) => {
  if (req.params.name) {
    let p = PlayerModel.players[req.params.name];
    if (p) {
      res.send(p);
    } else {
      res.status(404).send("Player '" + req.params.name + "' not found");
    }
  } else {
    res.status(400).send("Bad request: missing player name");
  }
};

exports.deletePlayer = (req, res) => {
  if (req.params.name) {
    let p = PlayerModel.players[req.params.name];
    if (p) {
      delete PlayerModel.players[req.params.name];
      res.send(p);
    } else {
      res.status(404).send("Player '" + req.params.name + "' not found");
    }
  } else {
    res.status(400).send("Bad request: missing player name");
  }
};

exports.updatePlayer=(req,res)=>{
    if(req.body){
      if(req.params.name){
             let p = PlayerModel.players[req.params.name];
          if(p){
              Object.entries(req.body).forEach(([action,result])=>{
                  currentRoom = getRoom(p.x,p.y);
                  switch(action){
                      case "playerItem":
                          if(result == 'pickup'){
                              if(currentRoom.items != null){
                                  if(currentRoom.items == ItemModel.items.timeBoost){
                                      //
                                      //TODO
                                      //increase time limit
                                      //
                                  }
                                  else{
                                      p.inventory = currentRoom.items;
                                      currentRoom.items=null;
                                  }
                              }  
                          }
                          if(result == 'drop'){
                              var itemHolder;
                              if(currentRoom.items != null){
                                  itemHolder = p.inventory;
                                  p.inventory = currentRoom.items;
                                  currentRoom.items = itemHolder;
                              }
                              else{
                                  currentRoom.items = p.inventory;
                                  p.inventory = null;
                              }
                          }    
                          break;
                      case "move":
                          if(result =='left' && currentRoom.doorLocation[1]==1){
                              nextRoom = getRoom(currentRoom.coordinates[0]-1,currentRoom.coordinates[1]);
                              if(nextRoom.challenges != null){
                                if(passChallenge(p.inventory,nextRoom) == true){
                                    nextRoom.challenges = null;
                                    p.inventory = null;
                                    p.x -= 1;
                                  }
                                  else{
                                      console.log("Key Required to enter room");
                                  }
                              }
                              else{
                                  p.x -= 1;
                              }
                          }
                          if(result =='right' && currentRoom.doorLocation[3]==1){
                              nextRoom = getRoom(currentRoom.coordinates[0]+1,currentRoom.coordinates[1]);
                              if(nextRoom.challenges != null){
                                if(passChallenge(p.inventory,nextRoom) == true){
                                    nextRoom.challenges = null;
                                    p.inventory = null;
                                    p.x += 1;
                                  }
                                  else{
                                      console.log("Key Required to enter room");
                                  }
                              }
                              else{
                                  p.x += 1;
                              }
                          }
                          if(result =='down' && currentRoom.doorLocation[0]==1){
                              nextRoom = getRoom(currentRoom.coordinates[0],currentRoom.coordinates[1]-1);
                              if(nextRoom.challenges != null){
                                if(passChallenge(p.inventory,nextRoom) == true){
                                    nextRoom.challenges=null;
                                    p.inventory = null;
                                    p.y -= 1;
                                  }
                                  else{
                                      console.log("Key Required to enter room");
                                  }
                              }
                              else{
                                  p.y -= 1;
                              }
                          }
                          if(result =='up' && currentRoom.doorLocation[2]==1){
                              nextRoom = getRoom(currentRoom.coordinates[0],currentRoom.coordinates[1]+1);
                              if(nextRoom.challenges != null){
                                if(passChallenge(p.inventory,nextRoom) == true){
                                    nextRoom.challenges=null;
                                    p.inventory = null;
                                    p.y += 1;
                                  }
                                  else{
                                      console.log("Key Required to enter room");
                                  }
                              }
                              else{
                                  p.y += 1;
                              }
                          }
                          
                          break;
                      case "health":
                          p.health = result;
                          break;
                      case "steps":
                          
                          //
                          //TODO
                          //either make it p.steps+=1, or set result at 1 when updating steps
                          //
                          
                          p.steps += result;
                          break;
                      default:
                          break;
                  }
                  res.status(200).send(p);
              });
          } else
              res.status(404).send();
        } else
            res.status(400).send("Player '"+req.params.name+"'is not found to update");
    }else
        res.status(400).send("Missing Player's data that need to be updated");
};


function getRoom(x,y){
    var roomList = Object.values(RoomModel.rooms);
    roomList = roomList.filter(room => room.coordinates[0] === x && room.coordinates[1] === y);
    return roomList[0];
}

function passChallenge(key,room){
    if(key!=null){
        if(key.name == room.challenges.solution){
            return true;
        }
    }
}










  // consider a move patch
  // as taking a direction name,
  // such as "left", and then
  // looking to see if there is a door
  // to the left, if so then add or
  // subtract player x/y and return
  // success, if not return error
  // move will be (x,y), or can change to p.x = result[0]... if want to make result an array.
  /*
  var newX = p.x;
  var newY = p.y;
  if (result=='left'){
      newX -= 1;
  }
  if (result=='right'){
      newX += 1;
  }
  if (result=='down'){
      newY -= 1;
  }
  if (result=='up'){
      newY += 1;
  }
  */
  //if room coordinates at [newX,newY], set p.x to newX, p.y to newY

  // TODO use Object.values to get a list of the
  // Room objects before filtering
  // TODO remember that filter returns a list,
  // so I'll need to get the Room at index 0
  // TODO cannot compare Array contents in JavaScript using ==,
  // so I need to find another way to compare
  // maybe separately compare x and 
// TODO if no Room is found, then
// send 403 Forbidden (with message can't go that way)
  //object can do key, values, entries

