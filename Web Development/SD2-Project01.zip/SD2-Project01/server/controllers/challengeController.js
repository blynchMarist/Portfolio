var ChallengeModel = require("../models/challenge.js");

exports.readAllChallenges = (req,res)=>{
    res.send(PlayerModel.players);
}
exports.createChallenge=(req,res)=>{
    if(req.body){
        if(req.body.id){
            let c = new ChallengeModel.Challenge(req.body.id,req.body.description,req.body.icon,req.body.solution,req.body.prevalence);
            ChallengeModel.challenges[c.id]=c;
            res.status(201).send(c);
        }else
            res.status(400).send('New challenge data must contain an id');    
    }else{
        res.status(400).send("Missing challenge data.");
    }
};
exports.readChallenge = (req,res)=>{
    if(req.params.id){
        let c = ChallengeModel.challenges[req.params.id];
        if(c){
            res.send(c);
        }else
            res.status(404).send("Challenge '" + req.params.id + "' not found");
    }else
        res.status(400).send("bad request: missing challenge id");
};

exports.deleteChallenge = (req,res)=>{
    if(req.params.id){
        let c = ChallengeModel.challenges[req.params.id];
        if(c){
            delete ChallengeModel.challenges[req.params.id];
            res.send(c);
        }else
            res.status(404).send("Challenge '"+req.params.id+"'not found");
    }else
        res.status(400).send("Bad request: missing Challenge id");
};

exports.updateChallenge=(req,res)=>{
    if(req.body){
        if(req.params.id){
            let c = ChallengeModel.challenges[req.challenge.id];
            if(c){
                Objects.entries(req.body).forEach(([action,result])=>{
                    switch(action){
                        case "description":
                            c.description = result;
                            break;
                        case "icon":
                            c.icon = result;
                            break;
                        case "solution":
                            c.solution = result;
                            break;
                        case "prevalence":
                            c.prevalence = result;
                            break;
                        case "completed":
                            c.completed = result;
                            break;
                        default:
                            break;
                            
                    }
                    res.status(201).send(c);
                });
            }else
                res.status(404).send(); 
        }else
            res.status(400).send("Challenge '"+req.params.id+"'not found");
    }else
        res.status(400).send("Missing challenge data");
};