var ItemModel = require("../models/item.js");

exports.readAllItems =(req,res)=>{
    res.send(ItemModel.items); 
};

exports.createItem=(req,res)=>{
    if(req.body){
        if(req.body.name && req.body.id && req.body.description && req.body.uses){
            let i = new ItemModel.Item(req.body.name,req.body.id,req.body.description,req.body.uses);
            ItemModel.items[i.name]=i;
            res.status(201).send(i);
        }
        else{
            res.status(400).send("new item data must contain name");
        }
    }
    else{
        res.status(400).send("Missing item data");
    }
};

exports.readItem=(req,res)=>{
    if(req.params.name){
        let i = ItemModel.items[req.params.name];
        if(i){
            res.send(i);
        }
        else{
            res.status(400).send("Item '" + req.params.name+ "' not found");
        }
    }
    else{
        res.status(400).send("Bad request: missing item name");
    }
};

exports.deleteItem=(req,res)=>{
    if(req.params.name){
        let i = ItemModel.items[req.params.name];
        if(i){
            delete ItemModel.items[req.params.name];
            res.send(i);
        }
        else{
            res.status(404).send("Item '"+req.params.name+"'not found");
        }
    }else{
        res.status(400).send("Bad request: missing item name");
    }
};

exports.updateItem=(req,res)=>{
    if(req.body){
      if(req.params.name){
            let i = ItemModel.items[req.params.name];
          if(i){
            if(req.body.uses)
                i.uses = req.body.uses;
            if(req.body.x)
                i.x = req.body.x;
            if(req.body.y)
                i.y = req.body.y;
            res.status(201).send(i);}
          else { res.status(400).send("Cannot find '"+req.params.name+"' to update");}
        }
        else{
            res.status(400).send("Missing the item name");
        }
    }
    else{
        res.status(400).send("Missing item's data that need to be updated");
    }
};

//exports.updateItem=(req,res)=>{
//    if(req.params.name){
//        let i = ItemModel.items[req.params.name,req.params.id,req.params.description,req.params.uses];
//        
//    }
//}
//Approach A
//chech that each of the attributes in the PATCH data are valid attributes of the Player model. if they are, then we update the corresponding PLayer instance witht he new atrribute values
//
//Approach B 
//use the custom "language" for instructions to the server. match the attributes of the PATCH data with the server's instruction "language"