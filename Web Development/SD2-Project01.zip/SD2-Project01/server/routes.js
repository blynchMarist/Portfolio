express  = require("express");
plyrCtlr  = require("./controllers/playerController");


router = express.Router();

router.route("/players")
  .get(plyrCtlr.readAllPlayers)
  .post(plyrCtlr.createPlayer);

router.route('/players/:name')
  .get(plyrCtlr.readPlayer)
  .delete(plyrCtlr.deletePlayer)
  .patch(plyrCtlr.updatePlayer);

//item routes

itemCtlr  = require("./controllers/itemController");

router.route("/items")
  .get(itemCtlr.readAllItems)
  .post(itemCtlr.createItem);

router.route('/items/:name')
  .get(itemCtlr.readItem)
  .delete(itemCtlr.deleteItem)
  .patch(itemCtlr.updateItem);

// TODO add remaining REST API routes that invoke methods on the appropriate controller

roomCtlr = require("./controllers/roomController.js");

router.route("/rooms")
    .get(roomCtlr.readAllRooms)
    .post(roomCtlr.createRoom);

router.route('/rooms/:x/:y')
    .get(roomCtlr.readRoom)
    .delete(roomCtlr.deleteRoom)
    .patch(roomCtlr.updateRoom);


challengeCtlr = require("./controllers/challengeController.js");

router.route("/challenges")
    .get(challengeCtlr.readAllChallenges)
    .post(challengeCtlr.createChallenge)

router.route("/challanges/:id")
    .get(challengeCtlr.readChallenge)
    .delete(challengeCtlr.deleteChallenge)
    .patch(challengeCtlr.updateChallenge);

module.exports = router;