function Item(name,id,description,uses) {
  this.name=name;
  this.id=id;
  this.description=description;
  this.uses=uses;
  this.x=0;
  this.y=0;
}



//took map off of items, going to auto display instead. Player can only hold onto one item at a time, makes easier than dealing with list size, also making game harder. 

exports.Item = Item;
exports.items = {
  "timeBoost": new Item("Time Boost",1,"adds time",1),
  "bronzeKey":new Item("bronzeKey",2,"opens door",1),
  "silverKey":new Item("silverKey",3,"opens door",2),
  "goldKey":new Item("goldKey",4,"opens door",1)             
};