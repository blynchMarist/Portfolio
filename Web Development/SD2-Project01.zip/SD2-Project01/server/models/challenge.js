//prevalence between 0-1, easy when using random generator
var PlayerModel = require("./player.js");

function Challenge(id,description,icon,solution,prevalence){
    this.id=id;
    this.description=description;
    this.icon=icon;
    this.solution=solution;
    this.prevalence=prevalence;
    this.completed=false;
};
exports.Challenge = Challenge;
exports.challenges={
    "requireBronzeKey": new Challenge(0,"Key required to unlocked this doorway",null,"bronzeKey",null),
    "requireSilverKey": new Challenge(1,"Silver key required to unlock this doorway",null,"silverKey",null),
    "requireGoldKey": new Challenge(2,"Gold key required to unlock this doorway",null,"goldKey",null),
};