const express = require('express');
const app = express();
const port = 3000;
app.use(express.static('client/public'));

app.get('/title', function (req, res) {
    res.sendFile('title.html', { root: './client/views' });
});

app.get('/game', function (req, res) {
res.sendFile('game.html', { root: './client/views' });
});

app.get('/menu', function (req, res) {
res.sendFile('menu.html', { root: './client/views' });
});

app.get('/options', function (req, res) {
res.sendFile('options.html', { root: './client/views' });
});

app.get('/credits', function (req, res) {
res.sendFile('credits.html', { root: './client/views' });
});

app.get('/about', function (req, res) {
res.sendFile('about.html', { root: './client/views' });
});

app.get('/winScreen', function(req,res){
res.sendFile('winScreen.html', { root: './client/views'});
});

app.get('/lossScreen', function(req,res){
res.sendFile('lossScreen.html', {root: './client/views'});
});

parser = require("body-parser");
routes = require("./routes.js");

app.use(parser.urlencoded({ extended: true }));
app.use(parser.json());

app.use("/api", routes);

app.listen(port, () => console.log(`Adventure app listening on port ${port}!`));

