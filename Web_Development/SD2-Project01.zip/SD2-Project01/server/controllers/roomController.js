
var RoomModel = require("../models/room.js");
exports.readAllRooms = (req,res)=>{
    res.send(RoomModel.rooms);
};

exports.createRoom = (req,res)=>{
    if(req.body){
        if(req.body.coordinates && req.body.dimensions && req.body.items && req.body.challenges && req.body.messages && req.body.doorLocation){
            let r = new RoomModel.Room(req.body.id,req.body.coordinates,req.body.dimensions,req.body.items,req.body.challenges,req.body.messages,req.body.doorLocation);
            RoomModel.rooms[r.id]=r;
            res.status(201).send(r);
        }
    }
    else{
        res.status(400).send("Missing item data");
    }
}

exports.readRoom = (req,res)=>{
    if(req.params.x && req.params.y){
        var r = getRoom(Number(req.params.x),Number(req.params.y));
        
        if(r)
            res.status(200).send(r);
        else
            res.status(403).send("Room not found, can not move player");
    }else{
        res.status(400).send("Bad request: missing room coordinates1");
    }
};

exports.deleteRoom = (req,res)=>{
    if(req.params.x && req.params.y){
        let r = getRoom(Number(req.params.x),Number(req.params.y));
        if(r){
            delete r;
            res.status(200).send();
        }else
            res.status(404).send("Room not found");
    }else
        res.status(400).send("Bad request:missing room coordinates");
};

exports.updateRoom = (req,res)=>{
    if(req.body){
        if(req.params.x && req.params.y){
            var r = getRoom(Number(req.params.x),Number(req.params.y));
            if(r){
                Object.entries(req.body).forEach(([action, result]) => {
                    switch(action){
                        case "coords":
                            r.xCoord = result.x;
                            r.yCoord = result.y;
                            r.coordinates = [r.xCoord,r.yCoord];
                            break;
                        case "dimensions":
                            r.xLength = result.x;
                            r.yLength = result.y;
                            r.dimensions = [r.xLength,r.yLength];
                            break;
                        case "items":
                            r.items = result;
                            break;
                        case "challenges":
                            r.challanges = result;
                            break;
                        case "messages":
                            r.messages.push(result);
                            break;
                        case "doorLocation":
                            r.doorLocation = result;
                            break;
                        default:
                            break;
                    }
                    res.status(201).send(r);
                });
            }else
                res.status(404).send();
        }else
            res.status(400).send("Room '"+req.params.id+"'not found");
    }else
        res.status(400).send("Missing player data");
};

function getRoom(x,y){
    var roomList = Object.values(RoomModel.rooms);
    roomList = roomList.filter(room => room.coordinates[0] === x && room.coordinates[1] === y);
    return roomList[0];
}