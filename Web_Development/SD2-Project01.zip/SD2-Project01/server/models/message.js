/*

var RoomModel = require("./room.js");

function Message(contents,room){
    this.contents=contents;
    this.room=room;
}

exports.Message = Message;
exports.messages = {
    startMessage: new Message("This is the starting room, follow the doors, find keys, make it to the finish!",getRoom(0,0))
}

function getRoom(x,y){
    var roomList = Object.values(RoomModel.rooms);
    roomList = roomList.filter(room => room.coordinates[0] === x && room.coordinates[1] === y);
    return roomList[0];
}

*/