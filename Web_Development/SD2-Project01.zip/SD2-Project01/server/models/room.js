var Item = require("./item.js");
var Challenge = require("./challenge.js");
var Message = require("./message.js");
//for door location, a size 4 array, one for each wall. 0 if door is not present , 1 if door is. [south,west,north,east].
//coordinates of room is size 2 array, start room at 0,0.
//dimensions size 2 arrray. Don't know if need, can make all a consistent size.
//items, challenges,messages will be stores as array lists as well
function Room(id, coordinates, dimensions, items, challenges, doorLocation){
    this.id = id;
    this.coordinates = coordinates;
    this.x = this.coordinates[0];
    this.y = this.coordinates[1];
    this.dimensions = dimensions;
    if(items)
        this.items=items;
    else
        this.items=null;
    if(challenges){
        this.challenges=challenges
    }
    else{
        this.challenges=null;
    }
    this.doorLocation=doorLocation;
    this.messages = [];
}

exports.Room = Room;
exports.rooms ={
    "room00": new Room(0,[0,0],[5,5],null,null,[0,0,1,0]),
    
    "room01": new Room(1,[0,1],[5,5],null,null,[1,0,1,0]),
    "room02": new Room(2,[2,1],[5,5],Item.items.timeBoost,null,[0,0,1,1]),
    "room03": new Room(3,[3,1],[5,5],null,null,[0,1,0,0]),
    
    "room04": new Room(4,[-4,2],[5,5],Item.items.bronzeKey,null,[0,0,1,1]),
    "room05": new Room(5,[-3,2],[5,5],null,null,[0,1,1,0]),
    "room06": new Room(6,[-1,2],[5,5],null,null,[0,0,1,1]),
    "room07": new Room(7,[0,2],[5,5],null,null,[1,1,1,1]),
    "room08": new Room(8,[1,2],[5,5],null,Challenge.challenges.requireBronzeKey,[0,1,0,1]),
    "room09": new Room(9,[2,2],[5,5],null,null,[1,1,1,0]),
    
    "room10": new Room(10,[-4,3],[5,5],null,null,[1,0,1,1]),
    "room11": new Room(11,[-3,3],[5,5],null,null,[1,1,0,1]),
    "room12": new Room(12,[-2,3],[5,5],null,null,[0,1,1,1]),
    "room13": new Room(13,[-1,3],[5,5],null,null,[1,1,0,1]),
    "room14": new Room(14,[0,3],[5,5],null,null,[1,1,0,0]),
    "room15": new Room(15,[2,3],[5,5],null,null,[1,0,1,0]),
    
    "room16": new Room(16,[-4,4],[5,5],Item.items.silverKey,null,[1,0,0,0]),
    "room17": new Room(17,[-3,4],[5,5],null,null,[0,0,0,1]),
    "room18": new Room(18,[-2,4],[5,5],null,null,[1,1,0,0]),
    "room19": new Room(19,[-1,4],[5,5],null,null,[0,0,1,1]),
    "room20": new Room(20,[0,4],[5,5],null,null,[0,1,0,0]),
    "room21": new Room(21,[2,4],[5,5],null,null,[1,0,1,1]),
    "room22": new Room(22,[3,4],[5,5],null,null,[0,1,1,0]),
    
    "room23": new Room(23,[-1,5],[5,5],null,null,[1,0,1,0]),
    "room24": new Room(24,[0,5],[5,5],null,Challenge.challenges.requireGoldKey,[0,0,1,1]),
    "room25": new Room(25,[1,5],[5,5],null,null,[0,1,1,0]),
    "room26": new Room(26,[2,5],[5,5],null,null,[1,0,1,0]),
    "room27": new Room(27,[3,5],[5,5],null,null,[1,0,1,1]),
    "room28": new Room(28,[4,5],[5,5],Item.items.goldKey,null,[0,1,0,1]),
    "room29": new Room(29,[5,5],[5,5],Item.items.timeBoost,null,[0,1,0,0]),
    
    "room30": new Room(30,[-3,6],[5,5],null,null,[0,0,0,1]),
    "room31": new Room(31,[-2,6],[5,5],null,null,[0,1,1,1]),
    "room32": new Room(32,[-1,6],[5,5],null,null,[1,1,0,1]),
    "room33": new Room(33,[0,6],[5,5],null,Challenge.challenges.requireSilverKey,[1,1,0,0]),
    "room34": new Room(34,[1,6],[5,5],null,null,[1,0,0,1]),
    "room35": new Room(35,[2,6],[5,5],null,null,[1,1,0,1]),
    "room36": new Room(36,[3,6],[5,5],null,null,[1,1,1,0]),
    
    "room37": new Room(37,[-3,7],[5,5],null,null,[0,0,1,1]),
    "room38": new Room(38,[-2,7],[5,5],null,null,[1,1,1,1]),
    "room39": new Room(29,[-1,7],[5,5],null,null,[0,1,1,0]),
    "room40": new Room(40,[1,7],[5,5],null,null,[0,0,1,0]),
    "room41": new Room(41,[3,7],[5,5],null,null,[1,0,0,0]),
    
    "room42": new Room(42,[-3,8],[5,5],Item.items.timeBoost,null,[1,0,0,0]),
    "room43": new Room(43,[-2,8],[5,5],null,null,[1,0,0,1]),
    "room44": new Room(44,[-1,8],[5,5],null,null,[1,1,1,1]),
    "room45": new Room(45,[0,8],[5,5],null,null,[0,1,1,1]),
    "room46": new Room(46,[1,8],[5,5],null,null,[1,1,0,0]),
    
    
    "room47": new Room(47,[-1,9],[5,5],null,null,[1,0,0,1]),
    
    "room48": new Room(48,[0,9],[5,5],null,null,[1,1,1,0]),
    
    "room49": new Room(49,[0,10],[5,5],null,null,[1,0,0,0]),
};
