function Player(name) {
  this.name = name;
  this.health = 100;
    this.steps=0;
    this.inventory=null;
    this.x = 0;
    this.y = 0;
    this.roomCoordinates = [this.x,this.y];
    this.time=60;
}

exports.Player = Player;
exports.players = {
  "Ahmed": new Player("Ahmed"),
  "Brian":   new Player("Brian"),
  "Tyler": new Player("Tyler"),
};