window.onload = function() {
    document.body.addEventListener('keypress', function(eventObj){
        //code 32 for spacebar
        if(eventObj.keyCode == 32){
            window.location.href = '/menu';
        }
    });
}
