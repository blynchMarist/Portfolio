const baseRoute = "http://localhost:3000/api/";
let playerRoute;
let player;

window.onload = async function () {
    
    const playerName = localStorage.getItem("playerName");
    if(playerName){
        const res = await fetch("http://localhost:3000/api/players/"+playerName);
        player = await res.json();
    }
    document.getElementById("myHeader").innerHTML = "WELCOME " + player.name;
    
    var startTimer=false;
    //setInterval(timer(),1000);
    async function timer(){
        if(startTimer){
            player.time -= 1;
            updateHUD(player);
        }
        if(player.time==0){
            window.location.href="/lossScreen"
        }
    }
    
    
    
    
    //player object and attributes now available
    
    let HUDPosition = document.getElementById("HUDPos");
    let HUDTime = document.getElementById("HUDTime");
    //let HUDHealth = document.getElementById("HUDHealth");
    let HUDInventory = document.getElementById("HUDInv");
    
    updateHUD(player);

    
    
    document.body.addEventListener('keyup', async function (eventObj) {
        let command;
        if (eventObj.key == "ArrowLeft"){
            command = 'left';
        }
        if(eventObj.key == "ArrowRight"){
            command = 'right';
        }
        if(eventObj.key == "ArrowDown"){
            command = 'down';
        }
        if(eventObj.key == "ArrowUp"){
            command = 'up';
        }
        if(eventObj.key == "e"){
            if(player.inventory == null){
                command = 'pickup';
            }
            else{
                command = 'drop';
            }
        }
        if(eventObj.key == "Escape"){
             window.location.href='/menu';
        }
        
        /*
        if(eventObj.key == 'q'){
            document.getElementById("messageForm").style.display = "block";
        }
        */
       /* document.getElementById("messageForm").addEventListener('submit', async evt => {
            evt.preventDefault();
            const message = evt.target.querySelector("input").value;
        });
        */
        
        if (command == 'left' || command == 'right' || command == 'down' || command == 'up'){
            await fetch("http://localhost:3000/api/players/"+player.name, {
                method: 'PATCH',
                body: JSON.stringify({
                    move : command,
                }),
                headers: {"Content-type": "application/json; charset=UTF-8"}
            });
        }
        if (command == "pickup" || command == "drop"){
            await fetch("http://localhost:3000/api/players/"+player.name, {
                method: 'PATCH',
                body: JSON.stringify({
                    playerItem : command,
                }),
                headers: {"Content-type": "application/json; charset=UTF-8"}
            });
        }
        
        const updateRes = await fetch("http://localhost:3000/api/players/"+player.name);
        player = await updateRes.json();
        updateHUD(player); 

        const roomRes = await fetch("http://localhost:3000/api/rooms/"+player.x+"/"+player.y);
        const room = await roomRes.json();
        
        if(room.items!=null){       
            document.getElementById(room.items.name).style.gridColumn = room.coordinates[0]+5;
            document.getElementById(room.items.name).style.gridRow = 11- room.coordinates[1];
            document.getElementById(room.items.name).style.display = "block";  
        }
        else{ 
            document.getElementById("bronzeKey").style.display = 'none';
            document.getElementById("silverKey").style.display = 'none';
            document.getElementById("goldKey").style.display = 'none';
        }
        if(room.messages.length>0){
            var tempStr = '';
            for(var i=0;i<room.messages.length;i++){
                tempStr += room.messages[i];
            }
            document.getElementById("h1").innerHTML = tempStr;
        }
        else{
            document.getElementById("h1").innerHTML = " ";
        }
    
        if(player.x==0 && player.y==10){
            window.location.href='/winScreen';
    }
    });
    
    
    
    function updateHUD(player){
        HUDPosition.innerHTML = "Position  "+ "x:"+player.x + " "+"y:"+player.y;
        //HUDHealth.innerHTML = "Health  " + player.health;
        
        if(player.inventory == null){
            HUDInventory.innerHTML = "Inventory";
        }
        else{
            HUDInventory.innerHTML = "Item: " + player.inventory.name;
        }
        
        document.getElementById("avatar").style.gridColumn = player.x+5;
        document.getElementById("avatar").style.gridRow = 11-player.y;
           
    };
    document.body.addEventListener('keyup',async function(eventObj){
        if (eventObj.key == 'q'){
            document.getElementById("messageForm").style.display = 'block';
            
        }
    });
    document.getElementById("messageForm").addEventListener('submit',async evt =>{
        evt.preventDefault();
        const message = evt.target.querySelector("input").value + " ";
        await fetch("http://localhost:3000/api/rooms/"+player.x+"/"+player.y, {
                method: 'PATCH',
                body: JSON.stringify({
                    messages : message,
                }),
                headers: {"Content-type": "application/json; charset=UTF-8"}
            });
        
    });
    
}





//          GAME GRAPHICS       \\
    
    /*async function getRoom(){
        const roomRes = await fetch("http://localhost:3000/api/rooms/"+player.x+"/"+player.y);
        const room = await roomRes.json();
        console.log(room);
        return room;
    }
    */
    /*
    function draw(roomSides){
        const canvas = document.getElementById("canvas");
        
        
        const roomShape = canvas.getContext('2d');
        roomShape.clearRect(0,0,300,300)
        //var img = new Image();
        //img.src = "images/avatar.png";
        //roomShape.drawImage(img,0,0)
        
        //sets each side with a door to brown
        for(var i=0;i<4;i++){
            if(roomSides[i]==1){
                roomSides[i] = "#D2691E";
            }
            else{
                roomSides[i] = "#000000";
            }
        }
        roomShape.beginPath();
        roomShape.moveTo(300,300);
        roomShape.lineTo(200,300);
        roomShape.strokeStyle = roomSides[0];
        roomShape.lineWidth = 5;
        roomShape.stroke();
        
        roomShape.beginPath();
        roomShape.moveTo(200,300);
        roomShape.lineTo(200,200);
        roomShape.strokeStyle = roomSides[1];
        roomShape.lineWidth = 5;
        roomShape.stroke();
        
        roomShape.beginPath();
        roomShape.moveTo(200,200);
        roomShape.lineTo(300,200);
        roomShape.strokeStyle = roomSides[2];
        roomShape.lineWidth = 5;
        roomShape.stroke();
        
        roomShape.beginPath();
        roomShape.moveTo(300,200);
        roomShape.lineTo(300,300);
        roomShape.strokeStyle = roomSides[3];
        roomShape.lineWidth = 5;
        roomShape.stroke();
        
    }
    
    */
    
















//        if (eventObj.key == 'ArrowLeft') {
//            // maybe instead of updating x/y, let the arrow key
//            // determine what direction is sent to the server
//            // e.g., if "ArrowLeft" is pressed, then
//            // you could send a
//            // PATCH /players/Brian {move:"left"}
//            // or
//            // PATCH /players/Brian {move: {x: newX, y: newY}}            
//            
//            
//            player.x -= 1;
//        }
//        if (eventObj.key == 'ArrowRight') {
//            player.x +=1;
//        }
//        if(eventObj.key == 'ArrowDown'){
//            player.y -= 1;
//        }
//        if(eventObj.key == 'ArrowUp'){
//            player.y += 1;
//        }
        
        // LOGIC ON THE SERVER-SIDE
        // instead of updating player x and y right away
        // send a PATCH request to the server to move the
        // player in the desired direction
        // [ server-side ]
        //      receive the desired movement direction
        //      from the request, and then check to see
        //      if the player's Room has a door in that
        //      direction, if so, update the player position
        //      here on the server-side and return 204
        //      if there is not door, then return 403 with
        //      a message like "cannot move right"
        // [ /server-side ]
        // if that request succeeds, then the player has
        // been successfully moved, and only then update
        // the client-side player position
        // if that request fails, then don't update the
        // client-side player position, but do tell the
        // player they can't go that direction

        
        // LOGIC ON THE CLIENT-SIDE
        // instead of updating player x and y right away
        // send a GET request to fetch the player's current
        // Room (if you haven't already)
        // [server-side]
        //      just get the room data
        // [/server-side]        
        // check to see if the player's Room has a door in
        // that direction, if so, send a PATCH request to
        // set the player's new position
        // [server-side]
        //      just set player pos to what the client said
        // [/server-side]        
        // if the PATCH succeeds, update the client-side
        // player position
        // if not, then don't update
        // if there is no door, then don't update the
        // client-side player position, but do tell the
        // player they can't go that direction




 /*
    //set Room data to null for now, could be useful in hud to display room information (items in room etc.), game data could pertain to time
    function updateHUD(playerData,roomData,gameData){
        
    }
    
    
    
    let HUDForm = document.getElementById("HUD");
    HUDForm.addEventListener("submit", evt => {
        evt.preventDefault();
        const HUDFormData = new FormData(document.getElementById("HUD"));
        //sets each item in hud list as own index in HUDData
        const HUDData = {};
        HUDFormData.forEach((value,key) => {HUDData[key] = value});
    });
    */ 

/*
    //          STARTS SECTION FROM OLD LABS
    
    var elemHeader; // TODO 1A. declare variables for each block element on the page
    var section;
    var form;
    var ul;
    var angle = 30;
    var position = 0;

    // selecting by tag name only works here because we don't have more than one header element
    elemHeader = document.querySelector('header');
    // TODO 2A. initialize each variable by selecting its corresponding element,
    //          use ID selectors where possible
    section = document.getElementById("HUD");
    form = document.getElementById("aForm");
    ul = document.getElementById("HUDList");
    // highlight elements so that 
    document.body.addEventListener('keypress', function (eventObj) {
        var style;

        if (eventObj.key == '1' && elemHeader.style.outlineStyle != 'solid') {
            style = 'solid';
        } else if (eventObj.key == '2' && elemHeader.style.outlineStyle != 'dotted') {
            style = 'dotted';a
        } else if (eventObj.key == '3' && elemHeader.style.outlineStyle != 'dashed') {
            style = 'dashed';
        } else if (eventObj.key == '4' && elemHeader.style.outlineStyle != 'groove') {
            style = 'groove';
        } else {
            style = 'none';
        }

        elemHeader.style.outlineStyle = style;
        form.style.outlineStyle = style;
        section.style.outlineStyle = style;
        ul.style.outlineStyle = style;
    });

    // TODO Find task 2B in the function below.
    elemHeader.addEventListener('click', highlightElement);
    section.addEventListener('click', highlightElement);
    form.addEventListener('click', highlightElement);
    ul.addEventListener('click', highlightElement);

    document.body.addEventListener('keyup', function (eventObj) {
        //var widget = document.querySelector('#aWidget');

        if (eventObj.key == 'ArrowLeft') {
            widget.style.transform = 'rotate('+angle+'deg)';
            angle = angle - 30;
        }
        if (eventObj.key == 'ArrowRight') {
            widget.style.transform = 'rotate('+angle+'deg)';
            angle = angle + 30;
        }

    });
    // TODO 1D and 2D. Work together to figure out how to rotate the widget image
    //                 clockwise/counterclockwise by 90 deg whenever the right/left
    //                 arrow keys are pressed
    
    //function to go back to the menu page



function highlightElement(eventObj) {
    var elemObj = eventObj.target;

    if (elemObj.style.filter == 'saturate(500%)') {
        elemObj.style.filter = '';
    } else {
        elemObj.style.filter = 'saturate(500%)';
    }
}
*/